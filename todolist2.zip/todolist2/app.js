const express = require('express')
const bodyParser = require('body-parser')

const app = express()

var item = "";

var tabListapp = [];
var cardList = [];


items = ["Design UI", "Design Algo", "Make prototype"];


app.use(express.urlencoded({ extended: true }));

app.use(express.static("public"))

app.set('view engine', 'ejs');


app.get('/', function (req, res) {


   var today = new Date();


   var options = {

      weekday: "long",

      day: "numeric",

      month: "long"

   };


   var day = today.toLocaleDateString("en-US", options)


   res.render("list", { KOD: day, newlist: items });

})



app.post('/', function (req, res) {

   var item = req.body.new

   items.push(item);
   //    console.log(item)

   res.redirect('/')

})


app.get('/table', function (req, res) {

   //    console.log(item)

   res.render('/table')

})



app.get('/table', function (req, res) {


   const objt = {

      name: req.body.nam,
      position: req.body.pos,
      salary: req.body.sal


   }

   console.log(objt)

   tabListapp.push(objt);



   res.render("table", { h1: "Full Name", h2: "Position", h3: "Salary", tabList: tabListapp });
   res.render('table')

   //   res.redirect('/table')

})




app.post('/table', function (req, res) {


   const objt = {

      name: req.body.nam,
      position: req.body.pos,
      salary: req.body.sal


   }

   console.log(objt)

   tabListapp.push(objt);



   res.render("table", { h1: "Full Name", h2: "Position", h3: "Salary", tabList: tabListapp });
   //   res.render('table')

   //   res.redirect('/table')

})





app.get('/table', function (req, res) {


   const objt = {

      name: req.body.nam,
      position: req.body.pos,
      salary: req.body.sal


   }

   console.log(objt)

   tabListapp.push(objt);



   res.render("table", { h1: "Full Name", h2: "Position", h3: "Salary", tabList: tabListapp });
   res.render('table')

   //   res.redirect('/table')

})




app.post('/card', function (req, res) {



   ITEM = req.body.item,
      PRICE = req.body.price,
      LINK = req.body.link




   console.log(req.body)





   res.render("card", { titleholder: ITEM, priceholder: PRICE, linkholder: LINK });

   res.render('card')

   //   res.redirect('/table')

})








// app.get('/card',function(req,res)
// {


//    res.render("card",{BC:"BitCoin",BCT:"Bitcoin to INR is the value of Indian currency per Bitcoin. As of today it stands at ₹29,40,000."});

//       })


app.listen(3000, function () {
   console.log('server loading')

})


